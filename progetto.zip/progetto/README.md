# Operating-System a.y. 2019/2020

Docente: Quaglia Francesco

Realizzazione di un servizio "talk" via internet gestito tramite server.

Il servizio tiene traccia di un elenco di client pronti ad iniziare una "conversazione".
I client (residenti, in generale, su macchine diverse), dopo essersi connessi al servizio acquisiscono
l'elenco e lo mostrano all'utente il quale potrà collegarsi a un altro utente disponibile iniziando così
la conversazione.

Due client collegati tra loro permetteranno ai relativi utenti di scambiarsi messaggi finche' uno dei
due non interrompe la conversazione, e saranno indisponibili ad altre conversazioni. Al termine di
una conversazione i client ritorneranno disponibili fino a che non si scollegano dal server.
Si precisa che la specifica richiede la realizzazione del software sia per l'applicazione client che per
l'applicazione server.

Per progetti misti Unix/Windows è a scelta quale delle due applicazioni sviluppare per uno dei due
sistemi.
